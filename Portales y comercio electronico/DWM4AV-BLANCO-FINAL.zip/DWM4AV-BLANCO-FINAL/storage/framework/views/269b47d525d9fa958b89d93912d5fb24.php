

<?php $__env->startSection('title', 'Mensajes de Contacto - Admin'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-section container">
    <div class="section-header">
        <h2>Mensajes recibidos</h2>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="admin-table-container">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Asunto</th>
                    <th>Mensaje</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $contactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contacto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($contacto->id); ?></td>
                        <td>
                            <?php echo e($contacto->nombre); ?>

                            <?php if($contacto->telefono): ?>
                                <br><small class="text-muted"><?php echo e($contacto->telefono); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><a href="mailto:<?php echo e($contacto->email); ?>"><?php echo e($contacto->email); ?></a></td>
                        <td><?php echo e($contacto->asunto); ?></td>
                        <td>
                            <span title="<?php echo e($contacto->mensaje); ?>">
                                <?php echo e(Str::limit($contacto->mensaje, 60)); ?>

                            </span>
                        </td>
                        <td>
                            <form method="POST" action="<?php echo e(route('admin.contactos.estado', $contacto)); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <?php echo method_field('PATCH'); ?>
                                <select name="estado" onchange="this.form.submit()"
                                    class="estado-select estado-<?php echo e($contacto->estado === 'nuevo' ? 'pendiente' : ($contacto->estado === 'leído' ? 'confirmada' : 'completada')); ?>">
                                    <option value="nuevo"      <?php echo e($contacto->estado === 'nuevo'      ? 'selected' : ''); ?>>🔵 Nuevo</option>
                                    <option value="leído"      <?php echo e($contacto->estado === 'leído'      ? 'selected' : ''); ?>>🟡 Leído</option>
                                    <option value="respondido" <?php echo e($contacto->estado === 'respondido' ? 'selected' : ''); ?>>🟢 Respondido</option>
                                </select>
                            </form>
                        </td>
                        <td><?php echo e($contacto->created_at->format('d/m/Y H:i')); ?></td>
                        <td>
                            <form method="POST" action="<?php echo e(route('admin.contactos.destroy', $contacto)); ?>"
                                  onsubmit="return confirm('¿Eliminar este mensaje?')">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">🗑 Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center p-8">
                            No hay mensajes de contacto todavía.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/admin/contactos/index.blade.php ENDPATH**/ ?>