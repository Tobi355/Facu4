

<?php $__env->startSection('title', 'Acceso Administrativo'); ?>

<?php $__env->startSection('content'); ?>
<section class="auth-page admin-login-page">
    <div class="container">
        <div class="section-header">
            <h2>Acceso <span>Administrativo</span></h2>
            <p>Ingrese sus credenciales administrativas</p>
        </div>

        <div class="form-container auth-card">
            <?php if($errors->any()): ?>
                <div class="form-error"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="admin_login" value="1">

                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" name="email" type="email" required>
                </div>

                <div class="form-group">
                    <label for="password">Contraseña</label>
                    <input id="password" name="password" type="password" required>
                </div>

                <button class="btn btn-primary" type="submit">Ingresar como Administrador</button>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/auth/admin-login.blade.php ENDPATH**/ ?>