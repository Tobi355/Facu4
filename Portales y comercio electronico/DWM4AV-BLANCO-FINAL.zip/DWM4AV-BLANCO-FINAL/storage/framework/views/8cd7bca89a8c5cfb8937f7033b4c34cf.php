<header>
    <div class="header-container">
        <a href="<?php echo e(route('home')); ?>" class="logo">
            <div class="logo-icon">WR</div>
            <span class="logo-text">White<span>Road</span></span>
        </a>

        <div class="menu-toggle">
            <span></span>
            <span></span>
            <span></span>
        </div>

        <nav>
            <ul>
                <li>
                    <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home') ? 'active' : ''); ?>">Inicio</a>
                </li>
                <li>
                    <a href="<?php echo e(route('servicios.index')); ?>" class="<?php echo e(request()->routeIs('servicios.*') ? 'active' : ''); ?>">Servicios</a>
                </li>
                <li>
                    <a href="<?php echo e(route('nosotros')); ?>" class="<?php echo e(request()->routeIs('nosotros') ? 'active' : ''); ?>">Nosotros</a>
                </li>
                <li>
                    <a href="<?php echo e(route('contacto')); ?>" class="<?php echo e(request()->routeIs('contacto') ? 'active' : ''); ?>">Contacto</a>
                </li>

                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-cart">
                        <a href="<?php echo e(route('cart.index')); ?>">
                            <span class="dropdown-icon">🛒</span>
                            <span>Ver carrito</span>
                        </a>
                    </li>

                    <?php if(Auth::user()->role === 'admin'): ?>
                        <li class="nav-admin">
                            <a href="<?php echo e(route('admin.dashboard')); ?>">Admin</a>
                        </li>
                    <?php endif; ?>

                    <li class="nav-user-container">
                        <button type="button" class="nav-user-btn" id="nav-user-toggle">
                            <span class="nav-user-avatar"><?php echo e(substr(Auth::user()->name, 0, 1)); ?></span>
                            <span class="nav-user-name"><?php echo e(Auth::user()->name); ?></span>
                            <span class="nav-user-arrow">▼</span>
                        </button>

                        <div class="nav-user-dropdown" id="nav-user-dropdown">
                            <a href="<?php echo e(route('perfil.index')); ?>">
                                <span class="dropdown-icon">👤</span>
                                <span>Mi Perfil</span>
                            </a>
                            <a href="<?php echo e(route('orders.index')); ?>">
                                <span class="dropdown-icon">👜</span>
                                <span>Mis compras</span>
                            </a>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <button type="submit">
                                    <span class="dropdown-icon">🚪</span>
                                    <span>Cerrar Sesión</span>
                                </button>
                            </form>
                        </div>
                    </li>
                <?php else: ?>
                    <li class="nav-admin">
                        <a href="<?php echo e(route('admin.login')); ?>">Admin</a>
                    </li>
                    <li class="nav-user-container">
                        <a href="<?php echo e(route('login')); ?>" class="nav-btn">Ingresar</a>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>
<?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/partials/navbar.blade.php ENDPATH**/ ?>