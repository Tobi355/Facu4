

<?php $__env->startSection('title', 'Categorías - Admin'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-section container">
    <div class="section-header">
        <h2>Categorías</h2>
        <a href="<?php echo e(route('admin.categorias.create')); ?>" class="btn btn-primary">+ Nueva Categoría</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="admin-table-container">
        <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Descripción</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($categoria->id); ?></td>
                    <td><?php echo e($categoria->nombre); ?></td>
                    <td><?php echo e($categoria->descripcion ?? 'N/A'); ?></td>
                    <td>
                        <span class="badge <?php echo e($categoria->estado === 'activo' ? 'badge-success' : 'badge-danger'); ?>">
                            <?php echo e(ucfirst($categoria->estado)); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.categorias.edit', $categoria)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('admin.categorias.destroy', $categoria)); ?>" method="POST" class="inline-form">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/admin/categorias/index.blade.php ENDPATH**/ ?>