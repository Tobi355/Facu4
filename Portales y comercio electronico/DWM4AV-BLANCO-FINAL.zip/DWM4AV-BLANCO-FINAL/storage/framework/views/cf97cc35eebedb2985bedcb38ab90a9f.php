

<?php $__env->startSection('content'); ?>

<div class="admin-section">
    <div class="section-header">
        <h2>Nuevo Servicio</h2>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.servicios.store')); ?>" method="POST">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

        <div class="form-group">
            <label for="nombre">Nombre *</label>
            <input type="text" id="nombre" name="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" required>
        </div>

        <div class="form-group">
            <label for="descripcion">Descripción *</label>
            <textarea id="descripcion" name="descripcion" class="form-control" rows="4" required><?php echo e(old('descripcion')); ?></textarea>
        </div>

        <div class="form-group">
            <label for="precio">Precio *</label>
            <input type="number" id="precio" name="precio" class="form-control" step="0.01" min="0" value="<?php echo e(old('precio')); ?>" required>
        </div>

        <div class="form-group">
            <label for="duracion">Duración *</label>
            <input type="text" id="duracion" name="duracion" class="form-control" value="<?php echo e(old('duracion')); ?>" placeholder="Ej: 30 minutos" required>
        </div>

        <div class="form-group">
            <label for="condiciones">Condiciones</label>
            <textarea id="condiciones" name="condiciones" class="form-control" rows="3"><?php echo e(old('condiciones')); ?></textarea>
        </div>

        <div class="form-group">
            <label for="categoria_id">Categoría *</label>
            <select id="categoria_id" name="categoria_id" class="form-control" required>
                <option value="">Seleccionar categoría...</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->id); ?>" <?php echo e(old('categoria_id') == $categoria->id ? 'selected' : ''); ?>>
                        <?php echo e($categoria->nombre); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="imagen">Imagen</label>
            <input type="text" id="imagen" name="imagen" class="form-control" value="<?php echo e(old('imagen')); ?>" placeholder="URL o nombre de archivo">
        </div>

        <div class="form-group">
            <label>
                <input type="checkbox" id="destacado" name="destacado" value="1" <?php echo e(old('destacado') ? 'checked' : ''); ?>>
                Destacado
            </label>
        </div>

        <div class="form-group">
            <label>
                <input type="checkbox" id="activo" name="activo" value="1" checked <?php echo e(old('activo') ? 'checked' : ''); ?>>
                Activo
            </label>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary">Crear Servicio</button>
            <a href="<?php echo e(route('admin.servicios.index')); ?>" class="btn btn-secondary">Cancelar</a>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/admin/servicios/create.blade.php ENDPATH**/ ?>