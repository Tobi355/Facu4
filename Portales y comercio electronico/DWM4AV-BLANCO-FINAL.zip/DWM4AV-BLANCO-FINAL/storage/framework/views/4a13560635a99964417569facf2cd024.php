

<?php $__env->startSection('title', $servicio->nombre); ?>

<?php $__env->startSection('content'); ?>
<section class="container">
    <div class="service-detail">
        <div class="service-detail-image">
            <?php $imgPath = public_path('storage/' . ($servicio->imagen ?? '')); ?>
            <?php if(!empty($servicio->imagen) && file_exists($imgPath)): ?>
                <img src="<?php echo e(asset('storage/' . $servicio->imagen)); ?>" alt="<?php echo e($servicio->nombre); ?>">
            <?php else: ?>
                <div class="placeholder">🔧</div>
            <?php endif; ?>
        </div>
        <div class="service-detail-info">
            <h2><?php echo e($servicio->nombre); ?></h2>
            <div class="service-detail-price"><?php echo e(number_format($servicio->precio, 0, ',', '.')); ?> ARS</div>
            <div class="service-detail-meta">
                <div class="meta-item">
                    <span>Duración</span>
                    <strong><?php echo e($servicio->duracion); ?></strong>
                </div>
                <div class="meta-item">
                    <span>Categoría</span>
                    <strong><?php echo e($servicio->categoria->nombre); ?></strong>
                </div>
            </div>
            <div class="service-detail-description">
                <h3>Descripción</h3>
                <p><?php echo e($servicio->descripcion); ?></p>
            </div>
            <?php if($servicio->condiciones): ?>
                <div class="service-detail-conditions">
                    <h3>Condiciones</h3>
                    <p><?php echo e($servicio->condiciones); ?></p>
                </div>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->role === 'admin'): ?>
                    <a href="<?php echo e(route('admin.servicios.index')); ?>" class="btn btn-primary">Gestionar servicios</a>
                <?php else: ?>
                    <form action="<?php echo e(route('cart.add', $servicio)); ?>" method="POST">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <button class="btn btn-primary">Agregar al carrito</button>
                    </form>
                <?php endif; ?>
            <?php else: ?>
                <p>Iniciá sesión para continuar con la compra de este servicio.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/servicios/show.blade.php ENDPATH**/ ?>