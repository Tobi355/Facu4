

<?php $__env->startSection('title', 'Carrito'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-5">

    <h1 class="mb-4 mt-3">Mi carrito</h1>

    <?php if(count($cart)): ?>

        <p class="text-muted mb-4">Podés ajustar la cantidad de cada servicio o eliminarlo directamente desde aquí.</p>

        <table class="table">
            <thead>
                <tr>
                    <th>Servicio</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>Subtotal</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
            <?php ($total = 0); ?>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($subtotal = $item['precio'] * $item['quantity']); ?>
                <?php ($total += $subtotal); ?>
                <tr>
                    <td><?php echo e($item['nombre']); ?></td>
                    <td>$<?php echo e(number_format($item['precio'],0,',','.')); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('cart.update', $item['id'])); ?>" class="d-flex gap-2 align-items-center">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <input type="number" name="quantity" value="<?php echo e($item['quantity']); ?>" min="0" class="form-control form-control-sm" style="max-width: 100px;">
                            <button class="btn btn-outline-primary btn-sm">Guardar</button>
                        </form>
                    </td>
                    <td>$<?php echo e(number_format($subtotal,0,',','.')); ?></td>
                    <td>
                        <form method="POST" action="<?php echo e(route('cart.remove',$item['id'])); ?>">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-danger btn-sm">
                                Eliminar
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <h3 class="text-end">
            Total:
            $<?php echo e(number_format($total,0,',','.')); ?>

        </h3>

        <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-primary">
            Continuar al checkout
        </a>

        <form method="POST" action="<?php echo e(route('cart.clear')); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <button class="btn btn-secondary">
                Vaciar carrito
            </button>
        </form>

    <?php else: ?>

        <div class="alert alert-info">
            No hay servicios agregados.
        </div>

    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/cart/index.blade.php ENDPATH**/ ?>