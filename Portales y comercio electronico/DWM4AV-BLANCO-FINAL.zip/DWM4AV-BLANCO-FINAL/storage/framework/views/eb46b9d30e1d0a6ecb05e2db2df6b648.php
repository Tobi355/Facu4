

<?php $__env->startSection('title','Mis Compras'); ?>

<?php $__env->startSection('content'); ?>

<div class="container py-5">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h1 class="fw-bold mb-1 mt-3">Mis Compras</h1>

            <p class="text-muted mb-0">

                Historial de todas tus órdenes.

            </p>

        </div>

    </div>

    <?php if($orders->count()): ?>

        <div class="table-responsive shadow-sm rounded">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-dark">

                    <tr>

                        <th>Orden</th>
                        <th>Fecha</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>

                    </tr>

                </thead>

                <tbody>

                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>

                        <td>

                            <strong>#<?php echo e($order->id); ?></strong>

                        </td>

                        <td>

                            <?php echo e($order->created_at->format('d/m/Y')); ?>


                            <br>

                            <small class="text-muted">

                                <?php echo e($order->created_at->format('H:i')); ?>


                            </small>

                        </td>

                        <td>

                            <strong>

                                $<?php echo e(number_format($order->total,0,',','.')); ?>


                            </strong>

                        </td>

                        <td>

                            <?php switch($order->status):

                                case ('pending'): ?>

                                    <span class="badge bg-warning text-dark">

                                        Pendiente

                                    </span>

                                    <?php break; ?>

                                <?php case ('paid'): ?>

                                    <span class="badge bg-success">

                                        Pagada

                                    </span>

                                    <?php break; ?>

                                <?php case ('completed'): ?>

                                    <span class="badge bg-primary">

                                        Terminada

                                    </span>

                                    <?php break; ?>

                                <?php case ('failed'): ?>

                                    <span class="badge bg-danger">

                                        Fallida

                                    </span>

                                    <?php break; ?>

                                <?php default: ?>

                                    <span class="badge bg-secondary">

                                        <?php echo e(ucfirst($order->status)); ?>


                                    </span>

                            <?php endswitch; ?>

                        </td>

                        <td class="text-center">

                            <a
                                href="<?php echo e(route('orders.show',$order)); ?>"
                                class="btn btn-outline-primary btn-sm">

                                Ver detalle

                            </a>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>

        </div>

        <div class="mt-4">

            <?php echo e($orders->links()); ?>


        </div>

    <?php else: ?>

        <div class="alert alert-info text-center">

            <h5 class="mb-2">

                Todavía no realizaste ninguna compra.

            </h5>

            <p class="mb-3">

                Cuando compres un servicio aparecerá aquí.

            </p>

            <a
                href="<?php echo e(route('servicios.index')); ?>"
                class="btn btn-primary">

                Ver servicios

            </a>

        </div>

    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/orders/index.blade.php ENDPATH**/ ?>