

<?php $__env->startSection('title', 'Órdenes'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1>Gestión de Órdenes</h1>
        <span class="badge bg-secondary fs-6">
            <?php echo e($orders->total()); ?> órdenes
        </span>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?php echo e(session('success')); ?>


            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert">
            </button>
        </div>
    <?php endif; ?>

    <form method="GET" action="<?php echo e(route('admin.orders.index')); ?>" class="row g-2 align-items-end mb-4">
        <div class="col-md-4">
            <label for="status" class="form-label">Filtrar por estado</label>
            <select id="status" name="status" class="form-select">
                <option value="">Todos</option>
                <option value="pending" <?php echo e(old('status', $status) === 'pending' ? 'selected' : ''); ?>>Pendiente</option>
                <option value="paid" <?php echo e(old('status', $status) === 'paid' ? 'selected' : ''); ?>>Pagada</option>
                <option value="completed" <?php echo e(old('status', $status) === 'completed' ? 'selected' : ''); ?>>Terminada</option>
                <option value="failed" <?php echo e(old('status', $status) === 'failed' ? 'selected' : ''); ?>>Fallida</option>
            </select>
        </div>

        <div class="col-md-2">
            <button type="submit" class="btn btn-primary">Aplicar</button>
        </div>
    </form>

    <div class="table-responsive">

        <table class="table table-hover align-middle">

            <thead class="table-dark">

                <tr>

                    <th>#</th>
                    <th>Cliente</th>
                    <th>Total</th>
                    <th>Estado</th>
                    <th>Fecha</th>
                    <th width="340">Acciones</th>

                </tr>

            </thead>

            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr>

                    <td>
                        <strong>#<?php echo e($order->id); ?></strong>
                    </td>

                    <td>

                        <strong><?php echo e($order->user->name); ?></strong>

                        <br>

                        <small class="text-muted">

                            <?php echo e($order->user->email); ?>


                        </small>

                    </td>

                    <td>

                        <strong>

                            $<?php echo e(number_format($order->total,0,',','.')); ?>


                        </strong>

                    </td>

                    <td>

                        <?php if($order->status == 'pending'): ?>

                            <span class="badge bg-warning text-dark">
                                Pendiente
                            </span>

                        <?php elseif(strtolower($order->status) == 'paid'): ?>

                            <span class="badge bg-success">
                                Pagada
                            </span>

                        <?php elseif(strtolower($order->status) == 'completed'): ?>

                            <span class="badge bg-primary">
                                Terminada
                            </span>

                        <?php elseif(strtolower($order->status) == 'failed'): ?>

                            <span class="badge bg-danger">
                                Fallida
                            </span>

                        <?php else: ?>

                            <span class="badge bg-secondary">
                                <?php echo e(ucfirst($order->status)); ?>

                            </span>

                        <?php endif; ?>

                    </td>

                    <td>

                        <?php echo e($order->created_at->format('d/m/Y')); ?>


                        <br>

                        <small class="text-muted">

                            <?php echo e($order->created_at->format('H:i')); ?>


                        </small>

                    </td>

                    <td>

                        <div class="d-flex flex-wrap gap-2">

                            <a
                                href="<?php echo e(route('admin.orders.show',$order)); ?>"
                                class="btn btn-outline-primary btn-sm">

                                Ver

                            </a>

                            <?php if($order->status == 'pending'): ?>

                                <form
                                    action="<?php echo e(route('admin.orders.paid',$order)); ?>"
                                    method="POST">

                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <?php echo method_field('PATCH'); ?>

                                    <button
                                        class="btn btn-success btn-sm">

                                        Marcar pagada

                                    </button>

                                </form>

                            <?php endif; ?>

                            <?php if($order->status == 'paid'): ?>

                                <form
                                    action="<?php echo e(route('admin.orders.completed',$order)); ?>"
                                    method="POST">

                                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                    <?php echo method_field('PATCH'); ?>

                                    <button
                                        class="btn btn-primary btn-sm">

                                        Terminar

                                    </button>

                                </form>

                            <?php endif; ?>

                            <form
                                action="<?php echo e(route('admin.orders.destroy',$order)); ?>"
                                method="POST"
                                onsubmit="return confirm('¿Eliminar esta orden?')">

                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <?php echo method_field('DELETE'); ?>

                                <button
                                    class="btn btn-outline-danger btn-sm">

                                    Eliminar

                                </button>

                            </form>

                        </div>

                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="6" class="text-center py-5">

                        <h5>No hay órdenes registradas.</h5>

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

    <div class="mt-4">

        <?php echo e($orders->links()); ?>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>