

<?php $__env->startSection('title', 'Mi Perfil'); ?>

<?php $__env->startSection('content'); ?>
<section class="container">
    <div class="profile-container">
        <aside class="profile-sidebar">
            <div class="profile-avatar"><?php echo e(substr($user->name, 0, 1)); ?></div>
            <h3 class="profile-name"><?php echo e($user->name); ?></h3>
            <p class="profile-email"><?php echo e($user->email); ?></p>
            <ul class="profile-menu">
                <li><a href="#" data-seccion="editar">Editar Perfil</a></li>
            </ul>
        </aside>
        <div class="profile-content">
            <div id="seccion-editar" >
                <h3>Editar Perfil</h3>
                <form method="POST" action="<?php echo e(route('perfil.update')); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> <?php echo method_field('PUT'); ?>
                    <div class="form-group">
                        <label>Nombre</label>
                        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" required>
                    </div>
                    <div class="form-group">
                        <label>Teléfono</label>
                        <input type="text" name="telefono" value="<?php echo e(old('telefono', $user->telefono)); ?>">
                    </div>
                    <div class="form-group">
                        <label>Nueva contraseña (dejar vacío para no cambiar)</label>
                        <input type="password" name="password">
                    </div>
                    <div class="form-group">
                        <label>Confirmar contraseña</label>
                        <input type="password" name="password_confirmation">
                    </div>
                    <button type="submit" class="btn btn-primary">Guardar cambios</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/perfil/index.blade.php ENDPATH**/ ?>