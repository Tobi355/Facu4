

<?php $__env->startSection('title', 'Usuarios - Admin'); ?>

<?php $__env->startSection('content'); ?>
<section class="admin-section container">
    <div class="section-header">
        <h2>Usuarios</h2>
        <a href="<?php echo e(route('admin.usuarios.create')); ?>" class="btn btn-primary">+ Nuevo Usuario</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="admin-table-container">
        <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Email</th>
                <th>Teléfono</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($usuario->id); ?></td>
                    <td><?php echo e($usuario->name); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td><?php echo e($usuario->telefono ?? 'N/A'); ?></td>
                    <td>
                        <span class="badge <?php echo e($usuario->role === 'admin' ? 'badge-info' : 'badge-secondary'); ?>">
                            <?php echo e(ucfirst($usuario->role)); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.usuarios.edit', $usuario)); ?>" class="btn btn-sm btn-secondary">Editar</a>
                        <?php if($usuario->id !== auth()->id()): ?>
                            <form action="<?php echo e(route('admin.usuarios.destroy', $usuario)); ?>" method="POST" class="inline-form ml-2">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro? Esta acción no se puede deshacer.')">Eliminar</button>
                            </form>
                        <?php else: ?>
                            <span class="text-muted ml-2">No podés eliminarte</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/admin/usuarios/index.blade.php ENDPATH**/ ?>