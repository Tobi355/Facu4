<footer>
    <div class="footer-content">
        <div class="footer-section">
            <h2>WhiteRoad</h2>
            <p>Tu taller de confianza para el mantenimiento y reparación de motocicletas.</p>
            <p>📍 Av. Siempre Viva 1234</p>
            <p>📞 (011) 4567-8901</p>
            <p>✉️ info@whiteroad.com</p>
        </div>

        <div class="footer-section">
            <h2>Enlaces</h2>
            <ul>
                <li><a href="<?php echo e(route('home')); ?>">Inicio</a></li>
                <li><a href="<?php echo e(route('servicios.index')); ?>">Servicios</a></li>
                <li><a href="<?php echo e(route('nosotros')); ?>">Nosotros</a></li>
                <li><a href="<?php echo e(route('contacto')); ?>">Contacto</a></li>
            </ul>
        </div>

        <div class="footer-section">
            <h2>Horarios</h2>
            <p>Lunes a Viernes: 8:00 - 18:00</p>
            <p>Sábados: 9:00 - 13:00</p>
            <p>Domingos: Cerrado</p>
        </div>

        <div class="footer-section footer-student">
            <h2>Alumno</h2>
            <p><strong>Nombre:</strong> Tobias Blanco</p>
            <p><strong>Edad:</strong> 21 años</p>
            <p><strong>Email:</strong> tobias.blanco@davinci.edu.ar</p>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; 2026 WhiteRoad - Taller de Motos. Todos los derechos reservados.</p>
    </div>
</footer><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/partials/footer.blade.php ENDPATH**/ ?>