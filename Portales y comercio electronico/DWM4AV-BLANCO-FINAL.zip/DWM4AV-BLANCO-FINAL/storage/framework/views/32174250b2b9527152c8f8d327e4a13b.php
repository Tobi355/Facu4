<?php $__env->startSection('title', 'Contacto'); ?>

<?php $__env->startSection('content'); ?>
<section class="container">
    <div class="section-header">
        <h2>Contacto</h2>
        <p>¿Tenés alguna consulta? Escribinos y te respondemos rápido.</p>
    </div>

    <div class="services-grid">
        <div class="card">
            <div class="auth-card">
                <h3>Información de contacto</h3>
                <div class="mb-3">
                    <h4 class="text-red mb-1">📍 Dirección</h4>
                    <p>Av. Siempre Viva 1234<br>Buenos Aires, Argentina</p>
                </div>
                <div class="mb-3">
                    <h4 class="text-red mb-1">📞 Teléfono</h4>
                    <p>(011) 4567-8901<br>(011) 15-1234-5678 (WhatsApp)</p>
                </div>
                <div class="mb-3">
                    <h4 class="text-red mb-1">✉️ Email</h4>
                    <p>info@whiteroad.com<br>turnos@whiteroad.com</p>
                </div>
                <div class="mb-3">
                    <h4 class="text-red mb-1">🕐 Horarios de atención</h4>
                    <p><strong>Lunes a Viernes:</strong><br>8:00 - 18:00 hs</p>
                    <p><strong>Sábados:</strong><br>9:00 - 13:00 hs</p>
                    <p><strong>Domingos:</strong><br>Cerrado</p>
                </div>
                <div>
                    <h4 class="text-red mb-1">📱 Redes Sociales</h4>
                    <p>
                    <a target="_blank" href="https://www.instagram.com/escueladavinci/?hl=es">Instagram</a> |
                    <a target="_blank" href="https://www.facebook.com/EscuelaDavinci/?locale=es_LA">Facebook</a> |
                    <a target="_blank" href="https://wa.me/5491112345678">WhatsApp</a>
                    </p>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-content">
                <h3>Formulario de Contacto</h3>

                
                <div id="contacto-messages" class="hidden"
                    data-success="<?php echo e(session('success') ? e(session('success')) : ''); ?>"
                    data-error="<?php echo e(session('error') ? e(session('error')) : ''); ?>"
                    data-errors='<?php echo json_encode($errors->any() ? ["Por favor complete los campos obligatorios."] : [], 15, 512) ?>'>
                </div>
                <?php $__env->startPush('scripts'); ?>
                    <script src="<?php echo e(asset('js/contacto.js')); ?>"></script>
                <?php $__env->stopPush(); ?>

                <form method="POST" action="<?php echo e(route('contacto.store')); ?>">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                    <div class="form-group">
                        <label for="nombre">Nombre *</label>
                        <input type="text" id="nombre" name="nombre" required value="<?php echo e(old('nombre')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" required value="<?php echo e(old('email')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <input type="tel" id="telefono" name="telefono" value="<?php echo e(old('telefono')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="asunto">Asunto *</label>
                        <input type="text" id="asunto" name="asunto" required value="<?php echo e(old('asunto')); ?>">
                    </div>

                    <div class="form-group">
                        <label for="mensaje">Mensaje *</label>
                        <textarea id="mensaje" name="mensaje" rows="6" required><?php echo e(old('mensaje')); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Enviar Mensaje</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/contacto.blade.php ENDPATH**/ ?>