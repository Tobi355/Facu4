

<?php $__env->startSection('title','Detalle Orden'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h1>Orden #<?php echo e($order->id); ?></h1>

    <hr>

    <p><strong>Cliente:</strong> <?php echo e($order->user->name); ?></p>

    <p><strong>Email:</strong> <?php echo e($order->user->email); ?></p>

    <p><strong>Estado:</strong> <?php echo e(match(strtolower($order->status)) { 'pending' => 'Pendiente', 'paid' => 'Pagada', 'completed' => 'Terminada', 'failed' => 'Fallida', default => ucfirst($order->status) }); ?></p>

    <p><strong>Total:</strong> $<?php echo e(number_format($order->total,0,',','.')); ?></p>

    <table class="table">

        <thead>

            <tr>

                <th>Servicio</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Subtotal</th>

            </tr>

        </thead>

        <tbody>

        <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>

                <td><?php echo e($item->servicio->nombre); ?></td>

                <td><?php echo e($item->quantity); ?></td>

                <td>$<?php echo e(number_format($item->price,0,',','.')); ?></td>

                <td>$<?php echo e(number_format($item->subtotal,0,',','.')); ?></td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>