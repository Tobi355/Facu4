

<?php $__env->startSection('title', 'Detalle de compra'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4 p-md-5">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                    <div>
                        <h1 class="fw-bold mb-1">Compra #<?php echo e($order->id); ?></h1>
                        <p class="text-muted mb-0">
                            Realizada el <?php echo e($order->created_at->format('d/m/Y H:i')); ?>

                        </p>
                    </div>

                    <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-outline-secondary">
                        ← Volver
                    </a>
                </div>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-lg-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-start gap-3">
                            <div>
                                <h5 class="card-title mb-3">Estado de la orden</h5>
                            </div>

                            <?php switch($order->status):
                                case ('pending'): ?>
                                    <span class="badge bg-warning-subtle text-warning-emphasis fs-6">Pendiente</span>
                                    <?php break; ?>

                                <?php case ('paid'): ?>
                                    <span class="badge bg-success-subtle text-success-emphasis fs-6">Pagada</span>
                                    <?php break; ?>

                                <?php case ('completed'): ?>
                                    <span class="badge bg-primary-subtle text-primary-emphasis fs-6">Terminada</span>
                                    <?php break; ?>

                                <?php case ('failed'): ?>
                                    <span class="badge bg-danger-subtle text-danger-emphasis fs-6">Fallida</span>
                                    <?php break; ?>

                                <?php default: ?>
                                    <span class="badge bg-secondary-subtle text-secondary-emphasis fs-6"><?php echo e(ucfirst($order->status)); ?></span>
                            <?php endswitch; ?>
                        </div>

                        <p class="text-muted mb-0">
                            <?php if($order->status === 'paid' || $order->status === 'completed'): ?>
                                Tu compra ya fue procesada correctamente.
                            <?php elseif($order->status === 'pending'): ?>
                                Está esperando confirmación o pago.
                            <?php elseif($order->status === 'failed'): ?>
                                Ocurrió un problema al procesar esta compra.
                            <?php else: ?>
                                Estado registrado en el sistema.
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 mt-2">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body p-4">
                        <h5 class="card-title mb-3">Total abonado</h5>
                        <h2 class="text-success mb-0">$<?php echo e(number_format($order->total, 0, ',', '.')); ?></h2>
                        <p class="text-muted mt-2 mb-0">Incluye todos los servicios contratados en esta compra.</p>
                    </div>
                </div>
            </div>
        </div>

            <div class="table-responsive mt-3">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light">
                        <tr>
                            <th scope="col">Servicio</th>
                            <th scope="col">Cantidad</th>
                            <th scope="col">Precio unitario</th>
                            <th scope="col">Subtotal</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($item->servicio->nombre); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td>$<?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                                <td><strong>$<?php echo e(number_format($item->subtotal, 0, ',', '.')); ?></strong></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">
                                    No hay servicios registrados en esta compra.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>

                    <?php if($order->items->isNotEmpty()): ?>
                        <tfoot>
                            <tr>
                                <th colspan="3" class="text-end">TOTAL</th>
                                <th>$<?php echo e(number_format($order->total, 0, ',', '.')); ?></th>
                            </tr>
                        </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/orders/show.blade.php ENDPATH**/ ?>