

<?php $__env->startSection('title', 'Servicios - Admin'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-section container">
    <div class="section-header">
        <h2>Servicios</h2>
        <a href="<?php echo e(route('admin.servicios.create')); ?>" class="btn btn-primary">+ Nuevo Servicio</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="admin-table-container">
        <table class="admin-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Categoría</th>
                <th>Precio</th>
                <th>Duración</th>
                <th>Activo</th>
                <th>Destacado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($servicio->id); ?></td>
                    <td><?php echo e($servicio->nombre); ?></td>
                    <td><?php echo e($servicio->categoria->nombre ?? 'N/A'); ?></td>
                    <td>$<?php echo e(number_format($servicio->precio, 0, ',', '.')); ?></td>
                    <td><?php echo e($servicio->duracion); ?></td>
                    <td>
                        <span class="badge <?php echo e($servicio->activo ? 'badge-success' : 'badge-danger'); ?>">
                            <?php echo e($servicio->activo ? 'Sí' : 'No'); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge <?php echo e($servicio->destacado ? 'badge-info' : ''); ?>">
                            <?php echo e($servicio->destacado ? 'Sí' : 'No'); ?>

                        </span>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.servicios.edit', $servicio)); ?>" class="btn btn-sm btn-warning">Editar</a>
                        <form action="<?php echo e(route('admin.servicios.destroy', $servicio)); ?>" method="POST" class="inline-form">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('¿Estás seguro?')">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/admin/servicios/index.blade.php ENDPATH**/ ?>