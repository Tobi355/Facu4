<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('content'); ?>

<section class="container">

    <div class="section-header">
        <h1>Nuestros <span>Servicios</span></h1>
        <p>Encontrá el servicio que necesita tu moto</p>
    </div>

    <div class="filters">

        <a href="<?php echo e(route('servicios.index')); ?>"
           class="filter-btn <?php echo e(empty($query) ? 'active' : ''); ?>">

            Todas

        </a>

        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(route('servicios.index', ['categoria' => $categoria->id])); ?>"
               class="filter-btn <?php echo e(isset($query) && $query == $categoria->id ? 'active' : ''); ?>">

                <?php echo e($categoria->nombre); ?>


            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <div class="services-grid">

        <?php $__empty_1 = true; $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <article class="service-card">

                <?php
                    $imgPath = public_path('storage/' . ($servicio->imagen ?? ''));
                ?>

                <?php if(!empty($servicio->imagen) && file_exists($imgPath)): ?>
                    <img
                        src="<?php echo e(asset('storage/' . $servicio->imagen)); ?>"
                        alt="<?php echo e($servicio->nombre); ?>"
                    >
                <?php else: ?>
                    <div class="card-image">🔧</div>
                <?php endif; ?>

                <div class="service-content">

                    <span class="service-category">

                        <?php echo e($servicio->categoria->nombre); ?>


                    </span>

                    <h2><?php echo e($servicio->nombre); ?></h2>

                    <p><?php echo e($servicio->descripcion); ?></p>

                    <p>

                        <strong>Duración:</strong>

                        <?php echo e($servicio->duracion); ?>


                    </p>

                    <p class="service-price">

                        $<?php echo e(number_format($servicio->precio, 0, ',', '.')); ?>


                    </p>

                    <a
                        href="<?php echo e(route('servicios.show', $servicio)); ?>"
                        class="btn btn-primary"
                    >
                        Ver detalle
                    </a>

                </div>

            </article>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <p>No hay servicios disponibles.</p>

        <?php endif; ?>

    </div>

</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/servicios/index.blade.php ENDPATH**/ ?>