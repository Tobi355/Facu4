

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>

<section class="admin-section container">

    <div class="section-header">
        <h2>Dashboard</h2>
        <p>Resumen general del sistema y actividad reciente.</p>
    </div>

    <div class="dashboard-stats">

        <div class="stat-card">
            <h4>Usuarios</h4>
            <span><?php echo e($totalUsuarios); ?></span>
        </div>

        <div class="stat-card">
            <h4>Servicios</h4>
            <span><?php echo e($totalServicios); ?></span>
        </div>

        <div class="stat-card">
            <h4>Órdenes</h4>
            <span><?php echo e($totalOrdenes); ?></span>
        </div>

        <div class="stat-card">
            <h4>Facturación</h4>
            <span>$<?php echo e(number_format($facturacionTotal,0,',','.')); ?></span>
        </div>

        <div class="stat-card">
            <h4>Pendientes</h4>
            <span><?php echo e($ordenesPendientes); ?></span>
        </div>

        <div class="stat-card">
            <h4>Pagadas</h4>
            <span><?php echo e($ordenesPagadas); ?></span>
        </div>

        <div class="stat-card">
            <h4>Terminadas</h4>
            <span><?php echo e($ordenesTerminadas); ?></span>
        </div>

        <div class="stat-card">
            <h4>Mensajes nuevos</h4>
            <span><?php echo e($totalContactos); ?></span>
        </div>

    </div>

    <div class="mt-5">

        <h3>Últimas órdenes</h3>

        <div class="admin-table-container">

            <table class="admin-table">

                <thead>

                    <tr>

                        <th>#</th>
                        <th>Cliente</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th>Fecha</th>

                    </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $ultimasOrdenes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>#<?php echo e($order->id); ?></td>

                        <td><?php echo e($order->user->name); ?></td>

                        <td>

                            $<?php echo e(number_format($order->total,0,',','.')); ?>


                        </td>

                        <td>

                            <?php switch(strtolower($order->status)):

                                case ('pending'): ?>

                                    <span class="badge bg-warning text-dark">

                                        Pendiente

                                    </span>

                                    <?php break; ?>

                                <?php case ('paid'): ?>

                                    <span class="badge bg-success">

                                        Pagada

                                    </span>

                                    <?php break; ?>

                                <?php case ('completed'): ?>

                                    <span class="badge bg-primary">

                                        Terminada

                                    </span>

                                    <?php break; ?>

                                <?php case ('failed'): ?>

                                    <span class="badge bg-danger">

                                        Fallida

                                    </span>

                                    <?php break; ?>

                                <?php default: ?>

                                    <?php echo e(ucfirst($order->status)); ?>


                            <?php endswitch; ?>

                        </td>

                        <td>

                            <?php echo e($order->created_at->format('d/m/Y H:i')); ?>


                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="5" class="text-center">

                            No hay órdenes registradas.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>