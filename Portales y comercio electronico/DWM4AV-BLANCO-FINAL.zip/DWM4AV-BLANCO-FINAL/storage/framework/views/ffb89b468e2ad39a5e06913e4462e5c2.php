<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Panel Administrador'); ?></title>
    <link rel="icon" href="<?php echo e(asset('storage/logo.png')); ?>" type="image/png">
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/hero-enhanced.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="admin-container">
        <aside class="admin-sidebar">
            <nav>
                <ul class="admin-menu">
                    <li><a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">Dashboard</a></li>
                    <li><a href="<?php echo e(route('admin.servicios.index')); ?>" class="<?php echo e(request()->routeIs('admin.servicios.*') ? 'active' : ''); ?>">Servicios</a></li>
                    <li><a href="<?php echo e(route('admin.categorias.index')); ?>" class="<?php echo e(request()->routeIs('admin.categorias.*') ? 'active' : ''); ?>">Categorías</a></li>
                    <li><a href="<?php echo e(route('admin.usuarios')); ?>" class="<?php echo e(request()->routeIs('admin.usuarios*') ? 'active' : ''); ?>">Usuarios</a></li>
                    <li><a href="<?php echo e(route('admin.contactos')); ?>" class="<?php echo e(request()->routeIs('admin.contactos') ? 'active' : ''); ?>">Contactos</a></li>
                    <li><a href="<?php echo e(route('admin.orders.index')); ?>" class="<?php echo e(request()->routeIs('admin.orders.*') ? 'active' : ''); ?>">Órdenes</a></li>
                </ul>
            </nav>
        </aside>

        <div class="admin-main">
            <main class="admin-content">
                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>

    <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <script src="<?php echo e(asset('js/hero3d.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ui.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/layouts/admin.blade.php ENDPATH**/ ?>