

<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h1>Resumen de compra</h1>

    <?php ($total = 0); ?>

    <table class="table">
        <thead>
            <tr>
                <th>Servicio</th>
                <th>Cantidad</th>
                <th>Precio</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($subtotal = $item['precio'] * $item['quantity']); ?>
                <?php ($total += $subtotal); ?>

                <tr>
                    <td><?php echo e($item['nombre']); ?></td>
                    <td><?php echo e($item['quantity']); ?></td>
                    <td>$<?php echo e(number_format($item['precio'], 0, ',', '.')); ?></td>
                    <td>$<?php echo e(number_format($subtotal, 0, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <h3 class="text-end">Total: $<?php echo e(number_format($total, 0, ',', '.')); ?></h3>

    <form method="POST" action="<?php echo e(route('checkout.store')); ?>">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <button class="btn btn-success">Confirmar compra</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Cosas\Facu4\Portales y comercio electronico\DWM4AV-BLANCO-FINAL\resources\views/checkout/index.blade.php ENDPATH**/ ?>