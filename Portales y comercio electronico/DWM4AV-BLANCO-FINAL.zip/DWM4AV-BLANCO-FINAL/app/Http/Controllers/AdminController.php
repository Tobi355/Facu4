<?php

namespace App\Http\Controllers;

use App\Models\Categoria;
use App\Models\ContactMessage;
use App\Models\Order;
use App\Models\Servicio;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AdminController extends Controller
{
    public function dashboard()
    {
        $totalUsuarios = User::count();

        $totalServicios = Servicio::where('activo', true)->count();

        $totalCategorias = Categoria::count();

        $totalContactos = ContactMessage::where('estado', 'nuevo')->count();

        // Órdenes
        $totalOrdenes = Order::count();

        $ordenesPendientes = Order::where('status', 'pending')->count();

        $ordenesPagadas = Order::where('status', 'paid')->count();

        $ordenesTerminadas = Order::where('status', 'completed')->count();

        $facturacionTotal = Order::whereIn('status', ['paid', 'completed'])
            ->sum('total');

        $ultimasOrdenes = Order::with('user')
            ->latest()
            ->take(5)
            ->get();

        return view('admin.dashboard', compact(
            'totalUsuarios',
            'totalServicios',
            'totalCategorias',
            'totalContactos',

            'totalOrdenes',
            'ordenesPendientes',
            'ordenesPagadas',
            'ordenesTerminadas',
            'facturacionTotal',
            'ultimasOrdenes'
        ));
    }

    public function usuarios()
    {
        $usuarios = User::all();

        return view('admin.usuarios.index', compact('usuarios'));
    }

    public function createUsuario()
    {
        return view('admin.usuarios.create');
    }

    public function storeUsuario(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:6|confirmed',
            'telefono' => 'nullable|string|max:20',
            'role' => 'required|in:user,admin',
        ]);

        User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'telefono' => $data['telefono'] ?? null,
            'role' => $data['role'],
        ]);

        return redirect()->route('admin.usuarios')->with('success', 'Usuario creado correctamente.');
    }

    public function editUsuario(User $user)
    {
        return view('admin.usuarios.edit', compact('user'));
    }

    public function updateUsuario(Request $request, User $user)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,'.$user->id,
            'password' => 'nullable|string|min:6|confirmed',
            'telefono' => 'nullable|string|max:20',
            'role' => 'required|in:user,admin',
        ]);

        $user->name = $data['name'];
        $user->email = $data['email'];
        $user->telefono = $data['telefono'] ?? null;
        $user->role = $data['role'];

        if (! empty($data['password'])) {
            $user->password = Hash::make($data['password']);
        }

        $user->save();

        return redirect()->route('admin.usuarios')->with('success', 'Usuario actualizado correctamente.');
    }

    public function destroyUsuario(User $user)
    {
        if ($user->id === Auth::id()) {
            return back()->with('error', 'No podés eliminarte a vos mismo.');
        }
        $user->delete();

        return back()->with('success', 'Usuario eliminado.');
    }

    public function contactos()
    {
        $contactos = ContactMessage::latest()->get();

        return view('admin.contactos.index', compact('contactos'));
    }

    public function cambiarEstadoContacto(Request $request, ContactMessage $contactMessage)
    {
        $request->validate(['estado' => 'required|in:nuevo,leído,respondido']);
        $contactMessage->estado = $request->estado;
        $contactMessage->save();

        return back()->with('success', 'Estado del mensaje actualizado.');
    }

    public function destroyContacto(ContactMessage $contactMessage)
    {
        $contactMessage->delete();

        return back()->with('success', 'Mensaje eliminado.');
    }
}
