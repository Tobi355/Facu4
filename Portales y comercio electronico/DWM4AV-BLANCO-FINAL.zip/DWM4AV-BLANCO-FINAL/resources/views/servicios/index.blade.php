@extends('layouts.app')

@section('title', 'Servicios')

@section('content')

<section class="container">

    <div class="section-header">
        <h1>Nuestros <span>Servicios</span></h1>
        <p>Encontrá el servicio que necesita tu moto</p>
    </div>

    <div class="filters">

        <a href="{{ route('servicios.index') }}"
           class="filter-btn {{ empty($query) ? 'active' : '' }}">

            Todas

        </a>

        @foreach($categorias as $categoria)

            <a href="{{ route('servicios.index', ['categoria' => $categoria->id]) }}"
               class="filter-btn {{ isset($query) && $query == $categoria->id ? 'active' : '' }}">

                {{ $categoria->nombre }}

            </a>

        @endforeach

    </div>

    <div class="services-grid">

        @forelse($servicios as $servicio)

            <article class="service-card">

                @php
                    $imgPath = public_path('storage/' . ($servicio->imagen ?? ''));
                @endphp

                @if(!empty($servicio->imagen) && file_exists($imgPath))
                    <img
                        src="{{ asset('storage/' . $servicio->imagen) }}"
                        alt="{{ $servicio->nombre }}"
                    >
                @else
                    <div class="card-image">🔧</div>
                @endif

                <div class="service-content">

                    <span class="service-category">

                        {{ $servicio->categoria->nombre }}

                    </span>

                    <h2>{{ $servicio->nombre }}</h2>

                    <p>{{ $servicio->descripcion }}</p>

                    <p>

                        <strong>Duración:</strong>

                        {{ $servicio->duracion }}

                    </p>

                    <p class="service-price">

                        ${{ number_format($servicio->precio, 0, ',', '.') }}

                    </p>

                    <a
                        href="{{ route('servicios.show', $servicio) }}"
                        class="btn btn-primary"
                    >
                        Ver detalle
                    </a>

                </div>

            </article>

        @empty

            <p>No hay servicios disponibles.</p>

        @endforelse

    </div>

</section>

@endsection

