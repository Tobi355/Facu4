<template>
  <div class="rounded-3xl border border-white/10 bg-white/5 p-5 shadow-soft backdrop-blur-xl transition-all duration-300 hover:border-primary/40 hover:bg-white/10">
    <div class="space-y-4">
      <div class="flex items-start gap-3">
        <img
          :src="post.user.avatar_url || avatarPlaceholder"
          :alt="post.user.username"
          class="h-11 w-11 rounded-2xl border border-white/10 object-cover"
        >
        <div class="flex-1">
          <router-link
            :to="{ name: 'profile', params: { username: post.user.username } }"
            class="font-semibold text-slate-100 hover:text-primary transition"
          >
            {{ post.user.username }}
          </router-link>
          <p class="text-sm text-slate-500 mt-1">
            {{ formatDate(post.created_at) }}
          </p>
        </div>
      </div>
      <div>
        <p class="text-slate-200 leading-relaxed whitespace-pre-line">
          {{ post.content }}
        </p>
      </div>
      <div v-if="post.image_url" class="mt-4 overflow-hidden rounded-3xl border border-white/10 bg-[#111113]">
        <img :src="post.image_url" alt="Post image" class="w-full object-cover" />
      </div>
      <div class="mt-4 flex flex-wrap items-center gap-3 text-sm text-slate-400">
        <button
          @click="toggleLike"
          :class="post.liked ? 'text-primary' : 'text-slate-400 hover:text-slate-100'"
          class="inline-flex items-center gap-2 transition"
        >
          <span>❤️</span>
          {{ post.likes_count }} Me gusta
        </button>
        <button
          @click="openComments"
          class="inline-flex items-center gap-2 text-slate-400 hover:text-slate-100 transition"
        >
          <span>💬</span>
          {{ post.comments_count }} Comentarios
        </button>
        <button
          v-if="isOwner"
          @click="handleDeletePost"
          class="inline-flex items-center gap-2 text-red-400 hover:text-red-200 transition"
        >
          <span>🗑️</span>
          Eliminar
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import avatarPlaceholder from '../assets/avatarPlaceHolder.png'
import { postService } from '../services/postService'
import { formatDate } from '../utils/dateUtils'
import { useToast } from 'vue-toastification'
import { useAuthStore } from '../stores/auth'
import { computed } from 'vue'

const props = defineProps({
  post: { type: Object, required: true }
})
const emit = defineEmits(['update:post', 'open-comments', 'delete:post'])
const toast = useToast()
const authStore = useAuthStore()

const isOwner = computed(() => authStore.user?.id === props.post.user?.id)

async function toggleLike() {
  try {
    await postService.toggleLike(props.post.id)
    props.post.likes_count = props.post.liked
      ? props.post.likes_count - 1
      : props.post.likes_count + 1
    props.post.liked = !props.post.liked
    emit('update:post', props.post)
  } catch (error) {
    toast.error('Error al dar like')
  }
}

function openComments() {
  emit('open-comments', props.post)
}

async function handleDeletePost() {
  try {
    await postService.deletePost(props.post.id)
    emit('delete:post', props.post.id)
    toast.success('Publicación eliminada')
  } catch (error) {
    toast.error(error.message || 'Error al eliminar la publicación')
  }
}
</script>