<template>
  <div class="p-3 bg-gray-50 dark:bg-gray-700 rounded">
    <div class="flex items-start space-x-2">
      <img :src="comment.user.avatar_url || avatarPlaceholder" :alt="`Avatar de ${comment.user.username}`" class="h-8 w-8 rounded-full object-cover">
      <div class="flex-1">
        <p class="font-medium text-gray-900 dark:text-gray-100">{{ comment.user.username }}</p>
        <p class="text-sm text-gray-500 dark:text-gray-400">{{ formatTime(comment.created_at) }}</p>
        
        <div v-if="isEditing" class="mt-2 space-y-2">
          <textarea
            v-model="editedContent"
            maxlength="300"
            rows="2"
            class="w-full rounded border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-gray-900 dark:text-gray-100"
            placeholder="Edita tu comentario..."
          ></textarea>
          <div class="flex justify-end gap-2">
            <button
              @click="handleCancelEdit"
              :disabled="loadingEdit"
              class="text-xs px-3 py-1 rounded text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600 disabled:opacity-50"
            >
              Cancelar
            </button>
            <button
              @click="handleSaveEdit"
              :disabled="loadingEdit || !editedContent.trim()"
              class="text-xs px-3 py-1 rounded bg-blue-500 text-white hover:bg-blue-600 disabled:opacity-50"
            >
              {{ loadingEdit ? 'Guardando...' : 'Guardar' }}
            </button>
          </div>
        </div>
        <p v-else class="text-gray-800 dark:text-gray-200 mt-1">{{ comment.content }}</p>
        
        <div v-if="canDelete || canEdit" class="flex items-center space-x-3 mt-2">
          <button
            v-if="canEdit && !isEditing"
            type="button"
            @click="handleEdit"
            class="text-xs text-blue-400 hover:text-blue-600"
            aria-label="Editar comentario"
          >
            Editar
          </button>
          <button
            v-if="canDelete && !isEditing"
            type="button"
            @click="handleDelete"
            :disabled="loadingDelete"
            class="text-xs text-red-400 hover:text-red-600 disabled:opacity-50 disabled:cursor-not-allowed"
            aria-label="Eliminar comentario"
            :aria-busy="loadingDelete"
          >
            {{ loadingDelete ? 'Eliminando...' : 'Eliminar' }}
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import avatarPlaceholder from '../assets/avatarPlaceHolder.png'
import { computed, ref } from 'vue'
import { useAuthStore } from '../stores/auth'
import { postService } from '../services/postService'
import { formatTime } from '../utils/dateUtils'
import { useToast } from 'vue-toastification'

const props = defineProps({
  comment: { type: Object, required: true }
})
const emit = defineEmits(['delete-comment', 'update:comment'])

const authStore = useAuthStore()
const toast = useToast()
const isEditing = ref(false)
const editedContent = ref('')
const loadingEdit = ref(false)
const loadingDelete = ref(false)

const canDelete = computed(
  () => authStore.user?.is_admin || 
         authStore.user?.id === props.comment.user_id || 
         authStore.user?.id === props.comment.user?.id
)

const canEdit = computed(
  () => authStore.user?.is_admin || 
         authStore.user?.id === props.comment.user?.id
)

function handleEdit() {
  editedContent.value = props.comment.content
  isEditing.value = true
}

function handleCancelEdit() {
  isEditing.value = false
  editedContent.value = ''
}

async function handleSaveEdit() {
  if (!editedContent.value.trim()) {
    toast.error('El contenido no puede estar vacío', { timeout: 0 })
    return
  }

  loadingEdit.value = true
  try {
    const updatedComment = await postService.updateComment(props.comment.id, editedContent.value.trim())
    emit('update:comment', updatedComment)
    isEditing.value = false
    editedContent.value = ''
    toast.success('Comentario actualizado')
  } catch (error) {
    toast.error(error.message || 'Error al actualizar el comentario', { timeout: 0 })
  } finally {
    loadingEdit.value = false
  }
}

async function handleDelete() {
  loadingDelete.value = true
  try {
    await postService.deleteComment(props.comment.id)
    emit('delete-comment', props.comment.id)
    toast.success('Comentario eliminado')
  } catch (error) {
    toast.error(error.message || 'Error al eliminar el comentario', { timeout: 0 })
  } finally {
    loadingDelete.value = false
  }
}
</script>