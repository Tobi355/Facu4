import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '../stores/auth'

const routes = [
  {
    path: '/',
    name: 'home',
    component: () => import('../views/HomeView.vue')
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('../pages/LoginView.vue')
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('../pages/RegisterView.vue')
  },
  {
    path: '/feed',
    name: 'feed',
    component: () => import('../pages/FeedView.vue')
  },
  {
    path: '/profile/:username',
    name: 'profile',
    component: () => import('../pages/ProfileView.vue')
  },
  {
    path: '/edit-profile',
    name: 'edit-profile',
    component: () => import('../pages/EditProfileView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  const requiresAuth = ['feed', 'edit-profile']

  if (requiresAuth.includes(to.name) && !authStore.user) {
    next({ name: 'login' })
  } else if (['login', 'register'].includes(to.name) && authStore.user) {
    next({ name: 'feed' })
  } else {
    next()
  }
})

export default router
