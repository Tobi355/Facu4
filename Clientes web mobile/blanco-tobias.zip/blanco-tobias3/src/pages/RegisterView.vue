<template>
  <div class="min-h-screen flex items-center justify-center ">
    <div class="w-full max-w-md space-y-8 p-8 rounded-3xl border border-white/10 bg-white/5 shadow-soft backdrop-blur-xl">
      <div class="space-y-4 text-center">
        <h2 class="text-center text-2xl font-bold text-slate-100">
          Registrate
        </h2>
        <p class="text-center text-slate-400">
          Únete a Nanu y comparte tu creatividad con la comunidad.
        </p>
      </div>
      <form @submit.prevent="handleRegister" class="space-y-6">
        <div>
          <label for="username" class="block text-sm font-medium text-slate-300 mb-2">
            Nombre de usuario
          </label>
          <input
            id="username"
            type="text"
            required
            autocomplete="username"
            maxlength="30"
            minlength="3"
            placeholder="Tu nombre de usuario"
            class="block w-full rounded-3xl border border-white/10 bg-[#111113] px-4 py-3 text-base text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary sm:text-sm"
            v-model="username"
            aria-required="true"
            aria-label="Nombre de usuario"
          />
          <p v-if="username.length > 0" class="mt-1 text-sm text-gray-500 dark:text-gray-400 text-right">
            {{ username.length }}/30
          </p>
        </div>
        <div>
          <label for="email" class="block text-sm font-medium text-slate-300 mb-2">
            Correo electrónico
          </label>
          <input
            id="email"
            type="email"
            required
            autocomplete="email"
            placeholder="tu@correo.com"
            class="block w-full rounded-3xl border border-white/10 bg-[#111113] px-4 py-3 text-base text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary sm:text-sm"
            v-model="email"
            aria-required="true"
            aria-label="Correo electrónico"
          />
        </div>
        <div>
          <label for="password" class="block text-sm font-medium text-slate-300 mb-2">
            Contraseña <span class="text-xs text-slate-400">(mínimo 6 caracteres)</span>
          </label>
          <input
            id="password"
            type="password"
            required
            autocomplete="new-password"
            minlength="6"
            placeholder="Tu contraseña segura"
            class="block w-full rounded-3xl border border-white/10 bg-[#111113] px-4 py-3 text-base text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary sm:text-sm"
            v-model="password"
            aria-required="true"
            aria-label="Contraseña"
          />
        </div>
        <div>
          <button
            type="submit"
            :disabled="loading"
            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50"
          >
            {{ loading ? 'Registrando...' : 'Regístrate' }}
          </button>
        </div>
        <p class="text-center text-sm text-slate-500">
          ¿Ya tenés una cuenta?
          <router-link to="/login" class="font-semibold text-secondary hover:text-accent transition">
            Iniciá sesión
          </router-link>
        </p>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useAuthStore } from '../stores/auth'
import { useRouter } from 'vue-router'
import { useToast } from 'vue-toastification'

const authStore = useAuthStore()
const router = useRouter()
const toast = useToast()

const username = ref('')
const email = ref('')
const password = ref('')
const loading = ref(false)

const handleRegister = async () => {
  const normalizedUsername = username.value.trim()
  const normalizedEmail = email.value.trim().toLowerCase()

  if (!normalizedUsername) {
    toast.error('El nombre de usuario es requerido', { timeout: 0 })
    return
  }

  if (normalizedUsername.length < 3) {
    toast.error('El nombre de usuario debe tener al menos 3 caracteres', { timeout: 0 })
    return
  }

  if (normalizedUsername.length > 30) {
    toast.error('El nombre de usuario no puede exceder 30 caracteres', { timeout: 0 })
    return
  }

  // Validación de email
  if (!normalizedEmail) {
    toast.error('Por favor, ingresá tu correo electrónico', { timeout: 0 })
    return
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
    toast.error('Ingresá un correo electrónico válido', { timeout: 0 })
    return
  }

  if (!password.value.trim()) {
    toast.error('Por favor, ingresá tu contraseña', { timeout: 0 })
    return
  }

  if (password.value.length < 6) {
    toast.error('La contraseña debe tener al menos 6 caracteres', { timeout: 0 })
    return
  }

  loading.value = true
  try {
    await authStore.register(normalizedEmail, password.value, normalizedUsername)
    toast.success('Registro exitoso. Por favor verifica tu correo electrónico.')
    router.push('/login')
  } catch (error) {
    toast.error(error.message || 'Error al registrar', { timeout: 0 })
  } finally {
    loading.value = false
  }
}
</script>